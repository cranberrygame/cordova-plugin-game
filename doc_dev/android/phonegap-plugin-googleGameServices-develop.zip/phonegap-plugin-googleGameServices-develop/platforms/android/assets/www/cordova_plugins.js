cordova.define('cordova/plugin_list', function(require, exports, module) {
module.exports = [
    {
        "file": "phonegap/plugin/googleGameService/googleGameService.js",
        "id": "com.github.aogilvie.phonegap.plugin.googleGameService",
        "clobbers": [
            "window.ggs"
        ]
    }];
module.exports.metadata = 
// TOP OF METADATA
{}
// BOTTOM OF METADATA
});