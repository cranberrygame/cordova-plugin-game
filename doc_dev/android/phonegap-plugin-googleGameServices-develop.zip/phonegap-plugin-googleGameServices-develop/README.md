# phonegap-plugin-googleGameServices


## ! IN PROGRESS !

This plugin is in very early development phase... 

## About

Cordova plugin for Google Game Services.

This is a volunteer project that I work and maintain in my free time. If this plugin works well for you, help me offer support by Pledging <a href='https://pledgie.com/campaigns/24952'><img alt='Click here to lend your support to: Google Play Services Phonegap Plugin. and make a donation at pledgie.com !' src='https://pledgie.com/campaigns/24952.png?skin_name=chrome' border='0' ></a>

Android Version: API 10+

Cordova Version: 3.0+

## Install (with plugman)

```
cordova plugin add https://github.com/aogilvie/phonegap-plugin-googleGameServices
``` 