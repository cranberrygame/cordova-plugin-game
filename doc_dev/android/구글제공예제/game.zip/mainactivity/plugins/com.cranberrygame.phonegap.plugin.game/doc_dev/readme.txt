1.

1)

https://github.com/playgameservices/android-basic-samples/tree/master/BasicSamples/TypeANumber

Google Play game services - Android Samples
https://github.com/playgameservices/android-basic-samples

Getting Started for Android Game Development
https://developers.google.com/games/services/

2)

Wizcorp/phonegap-plugin-gameCenter
https://github.com/Wizcorp/phonegap-plugin-gameCenter
https://github.com/Wizcorp/phonegap-plugin-gameCenter/blob/master/www/phonegap/plugin/gameCenterPlugin/gameCenterPlugin.js
https://github.com/Wizcorp/phonegap-plugin-gameCenter/tree/master/platforms/ios/HelloCordova

https://github.com/leecrossley/cordova-plugin-game-center

http://code.tutsplus.com/tutorials/ios-sdk-game-center-achievements-and-leaderboards-part-2--mobile-5801

2.

https://github.com/VCNinc/cordova-plugin-game-center#db2ccf7
