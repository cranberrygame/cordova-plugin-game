var Game = function() {
	this.onshow = null;
	this.onhide = null;
}

Game.prototype = {
	requestLogin: function(s, f) {
		cordova.exec(s, f, "Game", "requestLogin", []);
	},
	submitScore: function(category, score, s, f) {
		cordova.exec(s, f, "Game", "submitScore", [category, score]);
	},
	showLeaderboard: function(category) {
		cordova.exec(null, null, "Game", "showLeaderboard", [category]);
	},
//cranberrygame start
/*		
	submitAchievement: function(category, s, f) {
		cordova.exec(s, f, "Game", "submitAchievement", [category, 100]);
	},
*/
	submitAchievement: function(category, percent, s, f) {
		cordova.exec(s, f, "Game", "submitAchievement", [category, percent]);
	},
//cranberrygame end
	showAchievements: function() {
		cordova.exec(null, null, "Game", "showAchievements", []);
	},
	_viewDidShow: function() {
		if (typeof this.onshow === 'function') { this.onshow(); }
	},     
	_viewDidHide: function() {
		if (typeof this.onhide === 'function') { this.onhide(); }
	}
};    

var game = new Game();
module.exports = game;
