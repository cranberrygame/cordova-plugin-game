cordova.define('cordova/plugin_list', function(require, exports, module) {
module.exports = [
    {
        "file": "plugins/com.cranberrygame.phonegap.plugin.game/www/game.js",
        "id": "com.cranberrygame.phonegap.plugin.game.game",
        "clobbers": [
            "window.game"
        ]
    }
];
module.exports.metadata = 
// TOP OF METADATA
{
    "com.cranberrygame.phonegap.plugin.game": "1.0.8",
    "com.google.playservices": "19.0.0"
}
// BOTTOM OF METADATA
});