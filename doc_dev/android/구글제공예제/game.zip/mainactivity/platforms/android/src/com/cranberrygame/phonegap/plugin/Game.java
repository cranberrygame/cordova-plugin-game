// Copyright (c) 2014 cranberrygame
// Email: cranberrygame@yahoo.com
// Phonegap plugin: http://www.github.com/cranberrygame
// Construct2 phonegap plugin: https://www.scirra.com/forum/viewtopic.php?f=153&t=109586
//                             https://dl.dropboxusercontent.com/u/186681453/index.html
//                             https://www.scirra.com/users/cranberrygame
// Facebook: https://www.facebook.com/profile.php?id=100006204729846
// License: MIT (http://opensource.org/licenses/MIT)
package com.cranberrygame.phonegap.plugin;

import org.apache.cordova.CordovaPlugin;
import org.apache.cordova.PluginResult;
import org.apache.cordova.CallbackContext;
import org.json.JSONArray;
import org.json.JSONException;
import org.apache.cordova.CordovaInterface;
import org.apache.cordova.CordovaWebView;
import android.app.Activity;
import android.util.Log;
//

public class Game extends CordovaPlugin {
	//
	private String adUnit;
	
	@Override
	public boolean execute(String action, JSONArray args,CallbackContext callbackContext) {
		PluginResult result = null;
		
		try {		
			//args.length()
			//args.getString(0)
			//args.getString(1)
			//args.Int(0)
			//args.Int(1)
			//args.getBoolean(0)
			//args.getBoolean(1)

			if (action.equals("requestLogin")) {
				//Activity activity=cordova.getActivity();
				//webView
				//				
				final String adUnit = args.getString(0);				
				Log.d("Game", adUnit);
				
				final CallbackContext delayedCB = callbackContext;
				cordova.getActivity().runOnUiThread(new Runnable(){
		            @Override
		            public void run() {						
						_requestLogin(adUnit);
						
						delayedCB.sendPluginResult(new PluginResult(PluginResult.Status.OK));				
						//delayedCB.sendPluginResult(new PluginResult(PluginResult.Status.ERROR));						
		            }
		        });
				
				return true;
			}		
			else if (action.equals("submitScore")) {
				//Activity activity=cordova.getActivity();
				//webView
				//
				final String adUnit = args.getString(0);				
				Log.d("Game", adUnit);				
				final string position = args.getString(0);				
				Log.d("Game", position);
				
				final CallbackContext delayedCB = callbackContext;
		        cordova.getActivity().runOnUiThread(new Runnable(){
		            @Override
		            public void run() {						
						_submitScore(adUnit, position);
						
						delayedCB.sendPluginResult(new PluginResult(PluginResult.Status.OK));				
						//delayedCB.sendPluginResult(new PluginResult(PluginResult.Status.ERROR));						
		            }
		        });	
				
				return true;
			}		
			else if (action.equals("showLeaderboard")) {
				//Activity activity=cordova.getActivity();
				//webView
				//
				final String adUnit = args.getString(0);				
				Log.d("Game", adUnit);				
				final string position = args.getString(0);				
				Log.d("Game", position);
				
				final CallbackContext delayedCB = callbackContext;
		        cordova.getActivity().runOnUiThread(new Runnable(){
		            @Override
		            public void run() {						
						_showLeaderboard(adUnit, position);
						
						delayedCB.sendPluginResult(new PluginResult(PluginResult.Status.OK));				
						//delayedCB.sendPluginResult(new PluginResult(PluginResult.Status.ERROR));						
		            }
		        });	
				
				return true;
			}		
			else if (action.equals("submitAchievement")) {
				//Activity activity=cordova.getActivity();
				//webView
				//
				final String adUnit = args.getString(0);				
				Log.d("Game", adUnit);				
				final string position = args.getString(0);				
				Log.d("Game", position);
				
				final CallbackContext delayedCB = callbackContext;
		        cordova.getActivity().runOnUiThread(new Runnable(){
		            @Override
		            public void run() {						
						_submitAchievement(adUnit, position);
						
						delayedCB.sendPluginResult(new PluginResult(PluginResult.Status.OK));				
						//delayedCB.sendPluginResult(new PluginResult(PluginResult.Status.ERROR));						
		            }
		        });	
				
				return true;
			}		
			else if (action.equals("showAchievements")) {
				//Activity activity=cordova.getActivity();
				//webView
				//
				final String adUnit = args.getString(0);				
				Log.d("Game", adUnit);				
				final string position = args.getString(0);				
				Log.d("Game", position);
				
				final CallbackContext delayedCB = callbackContext;
		        cordova.getActivity().runOnUiThread(new Runnable(){
		            @Override
		            public void run() {						
						_showAchievements(adUnit, position);
						
						delayedCB.sendPluginResult(new PluginResult(PluginResult.Status.OK));				
						//delayedCB.sendPluginResult(new PluginResult(PluginResult.Status.ERROR));						
		            }
		        });	
				
				return true;
			}	
		}
		catch (JSONException e) {
		}
		
		callbackContext.sendPluginResult(new PluginResult(PluginResult.Status.ERROR));
		
		return false;	
	}
	//-------------------------------------
	private void _requestLogin(String adUnit){

	}	
	private void _submitScore(String adUnit, String position){
							
	}	
	private void _showLeaderboard(String adUnit, String position){
							
	}	
	private void _submitAchievement(String adUnit, String position){
							
	}	
	private void _showAchievements(String adUnit, String position){
							
	}	
}