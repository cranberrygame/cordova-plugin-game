1.

Fullscreen in browser: Scale outer

Export project-Windows Store-Export-Target version: Windows 8.0 (VS 2012)
