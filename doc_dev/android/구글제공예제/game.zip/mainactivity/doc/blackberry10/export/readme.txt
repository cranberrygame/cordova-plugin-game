
Enable WebGL: Off

Export project-Blackberry 10
