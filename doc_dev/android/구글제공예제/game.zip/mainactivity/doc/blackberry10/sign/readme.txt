
cd /d D:\certificate\playbook

ruby csj_install.rb
