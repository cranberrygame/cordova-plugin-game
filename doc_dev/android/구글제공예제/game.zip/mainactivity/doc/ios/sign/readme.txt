1.

certificate-ios-backup-TEAM_Sang Ki Kwon.developerprofile

2.

slidepuzzle.mobileprovision

3.

Build Settings-Code Signing-Code Signing Identity-Debug-Any iOS SDK: iOS Distribution
                                                  Release-Any iOS SDK: iOS Distribution
