1.

Fullscreen in browser: Scale outer

Export project-Windows Store-Export-Target version: Windows Phone 8.0 (VS2012 for Phone)
