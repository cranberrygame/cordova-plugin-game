1.

Fullscreen in browser: Scale outer

Export project-PhoneGap
