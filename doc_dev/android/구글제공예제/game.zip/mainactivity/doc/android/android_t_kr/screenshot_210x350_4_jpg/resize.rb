#!/usr/bin/ruby
$KCODE="utf8"

require "rubygems" #irb library path
if RUBY_PLATFORM=~/darwin/ # mac
	require "/Volumes/DataCenter/helper/ruby/lib/define.rb"
else
	path=File.expand_path(__FILE__)
	#drive= path[0,path.index("/")]
	drive= "d:"
	require drive+"/helper/ruby/lib/define.rb"
end
require "dir"
require "encoding"

#현재 루비파일이 메인 루비 파일이면 (현재 루비 파일을 실행한 것이면)
if __FILE__==$0 

  #uplus
	if RUBY_PLATFORM=~/darwin/ # mac
=begin		
		system "convert -resize 210x350 "+Dir.pwd+"/../../google/screenshot_480x800_4/1.png 1.jpg"
		system "convert -resize 210x350 "+Dir.pwd+"/../../google/screenshot_480x800_4/2.png 2.jpg"
		system "convert -resize 210x350 "+Dir.pwd+"/../../google/screenshot_480x800_4/3.png 3.jpg"
		system "convert -resize 210x350 "+Dir.pwd+"/../../google/screenshot_480x800_4/4.png 4.jpg"
		system "convert -resize 210x350 "+Dir.pwd+"/../../google/screenshot_480x800_4/5.png 5.jpg"
=end

		path=Dir.pwd+"/../../android/screenshot_480x800_4"
		arr=Dir["#{path}/*.png"]
		for i in 0..arr.size-1
			temp_arr=arr[i].split("/")
			save_filename=temp_arr[temp_arr.size-1]
			save_filename=save_filename.sub /\.png$/,".jpg"
			system "convert -resize 210x350 \""+arr[i]+"\" "+save_filename
			#puts arr[i]
			#puts replace_slash_in_windows_path(arr[i])
			#puts save_filename
		end

	else
=begin
		system "convert -resize 210x350 \""+replace_slash_in_windows_path(Dir.pwd+"/../../google/screenshot_480x800_4/1.png")+"\" 1.jpg"
		system "convert -resize 210x350 \""+replace_slash_in_windows_path(Dir.pwd+"/../../google/screenshot_480x800_4/2.png")+"\" 2.jpg"
		system "convert -resize 210x350 \""+replace_slash_in_windows_path(Dir.pwd+"/../../google/screenshot_480x800_4/3.png")+"\" 3.jpg"
		system "convert -resize 210x350 \""+replace_slash_in_windows_path(Dir.pwd+"/../../google/screenshot_480x800_4/4.png")+"\" 4.jpg"
		system "convert -resize 210x350 \""+replace_slash_in_windows_path(Dir.pwd+"/../../google/screenshot_480x800_4/5.png")+"\" 5.jpg"
=end		

		path=Dir.pwd+"/../../android/screenshot_480x800_4"
		arr=Dir["#{path}/*.png"]
		for i in 0..arr.size-1
			temp_arr=arr[i].split("/")
			save_filename=temp_arr[temp_arr.size-1]
			save_filename=save_filename.sub /\.png$/,".jpg"
			system "convert -resize 210x350 \""+replace_slash_in_windows_path(arr[i])+"\" "+save_filename
			#puts arr[i]
			#puts replace_slash_in_windows_path(arr[i])
			#puts save_filename
		end

	end
end
