1.appscovery

Google Play link	
	https://play.google.com/store/apps/details?id=com.cranberrygame.blockpuzzlegoogle
Amazon Appstore for Android
	http://www.amazon.com/block-puzzle-fill-fit-blocks/dp/B00GFRPM78/ref=sr_1_4?s=mobile-apps&ie=UTF8&qid=1392656143&sr=1-4&keywords=block+puzzle
BlackBerry App World
	http://appworld.blackberry.com/webstore/content/41154891
Apple App Store for iPhone
	https://itunes.apple.com/us/app/block-puzzle!/id738268654?mt=8&uo=4&at=11l9z8
Apple App Store for iPad
	https://itunes.apple.com/us/app/block-puzzle!/id738268654?mt=8&uo=4&at=11l9z8	
Windows Phone Marketplace	
		
2.mobile9


3.nexva

Google Play App id :

iTunes App Store App id :

4.opera


5.cnet

Product Download URL: 
	https://play.google.com/store/apps/details?id=com.cranberrygame.blockpuzzle
	https://itunes.apple.com/us/app/block-puzzle!/id738268654?mt=8&uo=4&at=11l9z8

Product Information URL: http://www.cranberrygame.com/

4.tucows

Home page URL: http://www.cranberrygame.com/

Product Support Page for the End-Users: http://www.cranberrygame.com/

Software URL: 
	https://play.google.com/store/apps/details?id=com.cranberrygame.blockpuzzle
	https://itunes.apple.com/us/app/block-puzzle!/id738268654?mt=8&uo=4&at=11l9z8
	http://appworld.blackberry.com/webstore/content/41154891
	