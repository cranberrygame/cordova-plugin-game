cordova.define('cordova/plugin_list', function(require, exports, module) {
module.exports = [
    {
        "file": "phonegap/plugin/gameCenterPlugin/gameCenterPlugin.js",
        "id": "jp.wizcorp.phonegap.plugin.gameCenterPlugin.gameCenterPlugin",
        "clobbers": [
            "window.gameCenter"
        ]
    }
];
module.exports.metadata = 
// TOP OF METADATA
{}
// BOTTOM OF METADATA
});